package tech.donau;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.resource.spi.ConfigProperty;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import tech.donau.data.Book;

@Path("/weather")
public class BookResource {

    @Inject
    EntityManager entityManager;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> hello() {
        List<Book> books = entityManager.createQuery("select b from Book b", Book.class).getResultList();

        return books;
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Book hello(Book b) {
        entityManager.persist(b);
        return b;
    }
}