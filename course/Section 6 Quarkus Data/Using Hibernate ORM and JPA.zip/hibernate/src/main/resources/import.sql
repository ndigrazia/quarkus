insert into Book values (1, 'sample');
insert into Book values (2, 'sample2');