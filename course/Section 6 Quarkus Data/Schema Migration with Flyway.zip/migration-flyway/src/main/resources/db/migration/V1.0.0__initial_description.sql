create table book(id int, name text);
insert into book values(1, 'test1');
insert into book values(2, 'test2');
