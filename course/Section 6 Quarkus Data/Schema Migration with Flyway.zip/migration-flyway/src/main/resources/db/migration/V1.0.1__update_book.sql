insert into book values(3, 'test1');
insert into book values(4, 'test2');
