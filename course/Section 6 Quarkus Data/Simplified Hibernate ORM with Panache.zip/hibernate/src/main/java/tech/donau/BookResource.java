package tech.donau;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.LockModeType;
import javax.persistence.Query;
import javax.resource.spi.ConfigProperty;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;
import tech.donau.data.Book;
import tech.repository.BookRepository;

@Path("/weather")
public class BookResource {

    //@Inject
    //EntityManager entityManager;

    @Inject
    BookRepository repository;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> hello() {
       // List<Book> books = entityManager.createQuery("select b from Book b", Book.class).getResultList();

       /*PanacheQuery<Book> query = Book.find("name", "sample");
       //query.page(Page.of(2, 50));
       query.page(Page.ofSize(50));
       List<Book> books = query.list();
       query.nextPage();
       books = query.list();*/

       //Book.listAll(Sort.by("name").ascending());

       //List<Book> books = Book.findAllBook();
       
       List<Book> books = repository.findAllBook();

        return books;
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Book hello(Book b) {
        //Book.findById("123", LockModeType.PESSIMISTIC_WRITE);
        //Book.find("name", "sample").withLock(LockModeType.WRITE);
        
        Book.persist(b);
        //entityManager.persist(b);
        return b;
    }

    @DELETE
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    @Path("/{id}")
    public long hello(@PathParam("id") long id) {
       // return Book.delete("id=?1", id);
      return repository.delete("id=?1", id);
    }
}