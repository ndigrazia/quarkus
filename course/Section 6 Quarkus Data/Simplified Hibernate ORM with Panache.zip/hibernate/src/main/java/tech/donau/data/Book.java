package tech.donau.data;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import io.quarkus.hibernate.orm.panache.PanacheEntity;

@Entity
public class Book extends PanacheEntity{

    public String name;

    public Book(){}

    /*public static List<Book> findAllBook() {
        return findAll().list();
    }

    public static List<Book> findAllBookByName(String name) {
        return find("name", name).list();
    }*/
}
