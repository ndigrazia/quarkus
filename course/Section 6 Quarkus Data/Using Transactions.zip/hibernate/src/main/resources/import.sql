insert into Author values (1, 'Stuard', 'Douglas');
insert into Author values (2, 'Charles', 'Chaplin');

insert into Book values (1, 'Book 1', 1);
insert into Book values (2, 'Book 2', 1);
insert into Book values (3, 'Book 3', 2);
insert into Book values (4, 'Book 4', 2);