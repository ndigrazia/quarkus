package tech.donau.data;

public class Weather {
    public String city;
    public String status;

    public Weather(String city, String status) {
        this.city = city;
        this.status = status;
    }
}
