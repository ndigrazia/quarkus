Using SSL:
  
  mvn io.quarkus:quarkus-maven-plugin:1.3.1.Final:create -DprojectGroupId=tech.donau -DprojectArtifactId=hello -DclassName="tech.donau.GreetingResource" -Dpath="/hello"

  install in our enviroment:
		sudo apt install certbot
  
  certbot certonly -a manual --preferred-challenges dns -d your.domain.com

  certbot certonly -a manual --preferred-challenges dns -d app-demo-quarkus-ssl.herokuapp.com
	
  -----------------------------------------------------------
  
  sudo openssl rand -out /home/vagrant/.rnd -hex 256
  sudo openssl req -newkey rsa:2048 -new -nodes -x509 -days 365 -keyout key.pem -out cert.pem
  openssl version -d -> OPENSSLDIR: "/usr/lib/ssl"
  
  openssl pkcs12 -export -out bundle.pfx -inkey key.pem -in cert.pem -password pass:testtest22
  
  Cariló Paradise Apart
  recep1paradise@gmail.com
  lun, 17 ene 2022 a sáb, 22 ene 2022
  lun, 24 ene 2022 a sáb, 29 ene 2022
  
  quarkus.http.port=80
  quarkus.http.ssl-port=443
  quarkus.http.ssl.certificate.key-store-file=/etc/letsencrypt/live/your.domain.com/bundle.pfx
  quarkus.http.ssl.certificate.key-store-file-type=PKCS12
  quarkus.http.ssl.certificate.key-store-password=testtest22
  ---------------------------------------------------------------------------------------------
