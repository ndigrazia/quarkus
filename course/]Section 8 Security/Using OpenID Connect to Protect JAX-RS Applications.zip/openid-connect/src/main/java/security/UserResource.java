package security;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.jboss.resteasy.annotations.cache.NoCache;

import io.quarkus.security.Authenticated;
import io.quarkus.security.identity.SecurityIdentity;

@Path("/users")
//@Authenticated
public class UserResource {
 
    @Inject
    SecurityIdentity identity;

    @GET
    @Produces(MediaType.APPLICATION_JSON)     
    @RolesAllowed("user")
    @NoCache
    public SecurityIdentity getUserInfo() {
        return identity;
    }


    @GET
    @Path("/admin")
    @Produces(MediaType.APPLICATION_JSON)     
    @RolesAllowed("admin")
    @NoCache
    public String getAdminInfo() {
        return "ADMIN is a Good";
    }
}
